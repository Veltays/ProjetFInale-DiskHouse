package DiskHouse.Controller;

import DiskHouse.view.AddMusic;
import DiskHouse.view.AddPlaylist;
import DiskHouse.view.MainPage;

import javax.swing.*;

public class MainPageController {

    private final MainPage view;

    public MainPageController(MainPage view) {
        this.view = view;
    }

    public void initController() {
        // --- Musique ---
        view.getAjouterMusique().addActionListener(e -> openAddMusic());
        view.getModifierMusique().addActionListener(e -> openAddMusic());
        view.getSupprimerMusique().addActionListener(e -> showDeleteMusicDialog());

        // --- Playlist ---
        view.getAjouterPlaylist().addActionListener(e -> openAddPlaylist());
        view.getModifierPlaylist().addActionListener(e -> openAddPlaylist());
        view.getSupprimerPlaylist().addActionListener(e -> showDeletePlaylistDialog());
    }

    private void openAddMusic() {
        // Ouvre la page d’ajout/édition musique
        new AddMusic(); // ta classe existante
    }

    private void openAddPlaylist() {
        // Ouvre la page d’ajout/édition playlist
        new AddPlaylist();
    }

    private void showDeleteMusicDialog() {
        JOptionPane.showMessageDialog(
                view,
                "Suppression d'une musique : logique à implémenter plus tard.",
                "Supprimer musique",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void showDeletePlaylistDialog() {
        JOptionPane.showMessageDialog(
                view,
                "Suppression d'une playlist : logique à implémenter plus tard.",
                "Supprimer playlist",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
