package DiskHouse.view;

import DiskHouse.Controller.MainPageController;

import javax.swing.*;

public class MainPage extends JFrame {
    private JPanel MainWindow;
    private JTable tablePlaylist;
    private JTable TablePlaylist;
    private JPanel InfoBouton;
    private JPanel Musique;
    private JPanel ListePlaylist;
    private JPanel ProfilPlaylist;
    private JPanel PlaylistNamePanel;
    private JPanel ButtonNamePanel;
    private JButton AjouterMusique;
    private JButton SupprimerMusique;
    private JButton ModifierMusique;
    private JLabel PhotoPlatlist;
    private JButton AjouterPlaylist;
    private JButton SupprimerPlaylist;
    private JButton ModifierPlaylist;
    private JScrollBar scrollBar1;
    private JScrollBar scrollBar2;

    public MainPage() {
        setTitle("DiskHouse");
        setContentPane(MainWindow); // respect du GridLayoutManager (UI Designer)
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Style visuel des boutons (laisse la logique au contrôleur)
        styliserBouton(AjouterMusique);
        styliserBouton(SupprimerMusique);
        styliserBouton(ModifierMusique);

        styliserBouton(AjouterPlaylist);
        styliserBouton(SupprimerPlaylist);
        styliserBouton(ModifierPlaylist);

        setVisible(true);
    }

    private void styliserBouton(JButton bouton) {
        if (bouton == null) return;
        bouton.setContentAreaFilled(false);
        bouton.setBorderPainted(false);
        bouton.setFocusPainted(false);
        bouton.setOpaque(false);
        // NOTE: ça n’empêche pas les clics.
    }

    // --- Getters pour le contrôleur ---
    public JButton getAjouterMusique()   { return AjouterMusique; }
    public JButton getSupprimerMusique() { return SupprimerMusique; }
    public JButton getModifierMusique()  { return ModifierMusique; }

    public JButton getAjouterPlaylist()   { return AjouterPlaylist; }
    public JButton getSupprimerPlaylist() { return SupprimerPlaylist; }
    public JButton getModifierPlaylist()  { return ModifierPlaylist; }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainPage view = new MainPage();
            new MainPageController(view).initController(); // <<< important
        });
    }
}
