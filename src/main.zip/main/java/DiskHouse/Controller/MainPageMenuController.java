package DiskHouse.Controller;

/**
 * Placeholder pour la logique de menu/barre d’actions globale de MainPage.
 * (Rien pour l’instant – tu pourras y ajouter les actions quand tu auras les items du menu.)
 */
public class MainPageMenuController {
    private final MainPageController root;
    public MainPageMenuController(MainPageController root) { this.root = root; }
    // À compléter plus tard (actions de menu, raccourcis, etc.)
}
