package DiskHouse.Controller;

import DiskHouse.view.ArtistEditor;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.util.Collection;
import java.util.Objects;

public class ArtisteEditorController implements IController<ArtistEditor> {

    private final ArtistEditor view;
    private String selectedImagePath;

    public ArtisteEditorController(ArtistEditor view) {
        this.view = Objects.requireNonNull(view);
    }

    @Override
    public ArtistEditor getView() { return view; }

    @Override
    public void initController() {
        // Portrait cliquable
        JLabel portrait = view.getPortraitLabel();
        portrait.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        portrait.setToolTipText("Cliquer pour choisir un portrait (png/jpg/jpeg)");
        portrait.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { onChooseImage(); }
        });

        // ✎ -> focus+selectAll
        view.getEditArtistButton().addActionListener(e -> {
            JTextField tf = view.getArtistNameField();
            tf.requestFocusInWindow();
            tf.selectAll();
        });

        // + / 🗑
        view.getAddAlbumButtonView().addActionListener(e -> onAddItem());
        view.getRemoveAlbumButtonView().addActionListener(e -> onRemoveSelectedItem());

        // Suppr
        view.getAlbumsList().getInputMap(JComponent.WHEN_FOCUSED)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), "del-item");
        view.getAlbumsList().getActionMap().put("del-item", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { onRemoveSelectedItem(); }
        });

        // Enter = valider
        JRootPane root = view.getRootPane();
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "validate");
        root.getActionMap().put("validate", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) {
                if (validateForm()) {
                    showInfo(view, "Artiste OK ✅", "Validation");
                }
            }
        });
    }

    /* ================= Actions UI ================= */

    private void onChooseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choisir un portrait");
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.addChoosableFileFilter(
                new FileNameExtensionFilter("Images (png, jpg, jpeg)", "png", "jpg", "jpeg")
        );

        if (chooser.showOpenDialog(view) == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) {
            selectedImagePath = chooser.getSelectedFile().getAbsolutePath();
            ImageIcon icon = new ImageIcon(selectedImagePath);
            view.setPortraitImage(icon.getImage());
        }
    }

    private void onAddItem() {
        String name = JOptionPane.showInputDialog(view, "Nom de l’album :", "Ajouter un album",
                JOptionPane.QUESTION_MESSAGE);
        if (name == null) return;
        name = name.trim();
        if (name.isEmpty()) {
            showError(view, "Le nom d’album est vide.", "Erreur");
            return;
        }
        DefaultListModel<String> model = getAlbumsModel();
        model.addElement(name);
        view.getAlbumsList().setSelectedIndex(model.getSize() - 1);
    }

    private void onRemoveSelectedItem() {
        int idx = view.getAlbumsList().getSelectedIndex();
        if (idx < 0) return;
        DefaultListModel<String> model = getAlbumsModel();
        String name = model.get(idx);
        int res = JOptionPane.showConfirmDialog(view,
                "Supprimer l’album \"" + name + "\" ?",
                "Confirmation",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE);
        if (res == JOptionPane.OK_OPTION) {
            model.remove(idx);
        }
    }

    /* ================= API modèle ================= */

    public void setAlbums(Collection<String> albums) {
        DefaultListModel<String> model = getAlbumsModel();
        model.removeAllElements();
        if (albums != null) {
            for (String a : albums) model.addElement(a);
        }
        if (model.size() > 0) view.getAlbumsList().setSelectedIndex(0);
    }

    public java.util.List<String> getAlbums() {
        DefaultListModel<String> model = getAlbumsModel();
        java.util.List<String> out = new java.util.ArrayList<>(model.size());
        for (int i = 0; i < model.size(); i++) out.add(model.get(i));
        return out;
    }

    public String getArtistName() {
        String v = view.getArtistNameField().getText();
        return v == null ? "" : v.trim();
    }

    public String getSelectedImagePath() { return selectedImagePath; }

    /* ================= Validation ================= */

    public boolean validateForm() {
        if (getArtistName().isEmpty()) {
            showError(view, "Le nom de l’artiste est requis.", "Erreur");
            return false;
        }
        return true;
    }

    /* ================= Helpers ================= */

    @SuppressWarnings("unchecked")
    private DefaultListModel<String> getAlbumsModel() {
        ListModel<String> lm = view.getAlbumsList().getModel();
        if (lm instanceof DefaultListModel<?> m) return (DefaultListModel<String>) m;

        DefaultListModel<String> fresh = new DefaultListModel<>();
        for (int i = 0; i < lm.getSize(); i++) fresh.addElement(lm.getElementAt(i));
        view.getAlbumsList().setModel(fresh);
        return fresh;
    }
}
