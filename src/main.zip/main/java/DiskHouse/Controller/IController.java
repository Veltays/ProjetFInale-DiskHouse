package app.controller;

import java.awt.Component;

/**
 * Contrat commun à tous les contrôleurs (MVC).
 * V = type de la vue (JPanel, JFrame, JDialog… -> doit au moins être un Component)
 * M = type du modèle (ton AppModel/DAO/etc.)
 */
public interface IController<V extends Component, M> {

    /** Injecte la vue (créée par l'UI Designer, GridLayoutManager, etc.). */
    void setView(V view);

    /** Injecte le modèle (DAO/singleton/… selon ton app). */
    void setModel(M model);

    /** Renvoie la vue gérée par ce contrôleur. */
    V getView();

    /** Renvoie le modèle géré par ce contrôleur. */
    M getModel();

    /**
     * Initialise le contrôleur : instanciation de services, formatters,
     * valeurs par défaut, chargement initial, etc.
     * Appelé une fois au démarrage du contrôleur.
     */
    void initController();

    /**
     * Connecte tous les listeners (ActionListener, ListSelectionListener…)
     * aux composants de la vue. Aucun changement d’UI, juste le câblage.
     */
    void bindEvents();

    /**
     * Charge les données du modèle vers la vue (remplir JTable, combos, champs…).
     * Idempotent : peut être rappelé pour recharger.
     */
    void loadData();

    /**
     * Rafraîchit l’affichage (ex: revalider le TableModel, repaint/revalidate).
     * Ne recharge pas la source, juste le rendu.
     */
    void refreshView();

    /**
     * Réinitialise l’UI (vider formulaire, remettre sélections par défaut).
     */
    void clearView();

    /** Montre la vue (setVisible(true), pack si nécessaire). */
    void showView();

    /** Cache la vue (setVisible(false)). */
    void hideView();

    /** Libère les ressources si nécessaire (déréférencer listeners, etc.). */
    void dispose();
}